import pika
import json
import model  # Se asume que se usa la API de model (operaciones directas a la BD)

connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
channel = connection.channel()
channel.exchange_declare(exchange='twitter-exchange', exchange_type='fanout', durable=False)
channel.queue_declare(queue='twitter-queue', durable=False)
channel.queue_bind(exchange='twitter-exchange', queue='twitter-queue', routing_key='')

def callback(ch, method, properties, body):
    print(f"Received: {body}")
    msg = json.loads(body)
    try:
        if msg['type'] == 'addUser': 
            print('add user')
            model.addUser(msg['data'])
        elif msg['type'] == 'updateUser': 
            print('update user')
            # Se corrige el error en el paso de parámetros
            model.updateUser(msg['token'], msg['data'])
        elif msg['type'] == 'removeUser':
            print('remove user')
            model.removeUser(msg['data'])
        elif msg['type'] == 'follow':
            print('follow')
            # Se espera que msg['data'] contenga "token" y "nick"
            model.follow(msg['data']['token'], msg['data']['nick'])
        elif msg['type'] == 'unfollow':
            print('unfollow')
            # Se espera que msg['data'] contenga "token" y "nick"
            model.unfollow(msg['data']['token'], msg['data']['nick'])
        elif msg['type'] == 'addTweet':
            print('add tweet')
            # Se espera que msg['data'] contenga "token" y "content"
            model.addTweet(msg['data']['token'], msg['data']['content'])
        elif msg['type'] == 'addRetweet':
            print('add retweet')
            # Se espera que msg['data'] contenga "token" y "tweetId"
            model.addRetweet(msg['data']['token'], msg['data']['tweetId'])
        elif msg['type'] == 'like':
            print('like')
            # Se espera que msg['data'] contenga "token" y "tweetId"
            model.like(msg['data']['token'], msg['data']['tweetId'])
        elif msg['type'] == 'dislike':
            print('dislike')
            # Se espera que msg['data'] contenga "token" y "tweetId"
            model.dislike(msg['data']['token'], msg['data']['tweetId'])
        else:
            print("Tipo de mensaje desconocido")
    except Exception as exc:
        print(f"Error processing message: {exc}")

channel.basic_consume(queue='twitter-queue', on_message_callback=callback, auto_ack=True)
channel.start_consuming()